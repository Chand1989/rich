<h4>E-Commerce Shoping Website</h4>
<h6>Home Page</h6>
<p align="center">
  <img src="https://user-images.githubusercontent.com/40789486/112491921-ca1e4100-8da6-11eb-96cf-936082fb248a.png" />
</p>
<h6>Product Details Page</h6>
<p align="center">
  <img src="https://user-images.githubusercontent.com/40789486/112473157-01372700-8d94-11eb-9600-654133cb2fd2.png" />
</p>
<h6>Add to cart page/Chekout Page</h6>
<p align="center">
  <img src="https://user-images.githubusercontent.com/40789486/112472788-8bcb5680-8d93-11eb-80cc-bad97c502e30.png" />
</p>
<h6>Order Placed Page</h6>
<p align="center">
  <img src="https://user-images.githubusercontent.com/40789486/112472863-9ede2680-8d93-11eb-9181-c04f1f188976.png" />
</p>
